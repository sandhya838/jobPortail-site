import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';
@Component({
  selector: 'app-side-listbox',
  templateUrl: './side-listbox.component.html',
  styleUrls: ['./side-listbox.component.scss']
})
export class SideListboxComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
